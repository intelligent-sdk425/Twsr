package dev.rustdroid

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var out: TextView
    private lateinit var title: TextView
    private var current: String? = null
    private var busy = false

    private val template = "fn main() {\n    println!(\"Olá, Rust no Android!\");\n}\n"
    private val rules = listOf(
        Regex("\\b(fn|let|mut|pub|use|mod|struct|enum|impl|trait|match|if|else|for|while|loop|return|self|Self|const|static|as|in|where|async|await|move|ref|crate|super|true|false|type|unsafe|dyn)\\b") to Color.parseColor("#C678DD"),
        Regex("\\b\\d[\\d_.]*\\b") to Color.parseColor("#D19A66"),
        Regex("\\b\\w+!") to Color.parseColor("#61AFEF"),
        Regex("\"(\\\\.|[^\"\\\\])*\"") to Color.parseColor("#98C379"),
        Regex("//.*") to Color.parseColor("#7F848E"),
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#21252B")) }
        val bar = LinearLayout(this).apply { setPadding(dp(4), dp(28), dp(4), dp(4)) }
        for ((label, f) in listOf<Pair<String, () -> Unit>>(
            "▶ Rodar" to { call("execute") }, "✓ Clippy" to { call("clippy") }, "⌗ Formatar" to { call("format") },
            "＋ Novo" to ::newFile, "📂 Abrir" to ::openFile, "💾 Salvar" to ::save)) {
            bar.addView(Button(this).apply { text = label; isAllCaps = false; setOnClickListener { f() } })
        }
        root.addView(HorizontalScrollView(this).apply { addView(bar) })
        title = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(dp(12), 0, 0, dp(4)) }
        root.addView(title)
        editor = EditText(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 14f
            setTextColor(Color.parseColor("#ABB2BF")); setBackgroundColor(Color.parseColor("#282C34"))
            gravity = Gravity.TOP; setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable) = highlight(e)
            })
            setText(template)
        }
        root.addView(editor, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        out = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(Color.parseColor("#E5C07B"))
            setPadding(dp(12), dp(8), dp(12), dp(8)); text = "Saída aparece aqui."
        }
        root.addView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(out) }, LinearLayout.LayoutParams(MATCH_PARENT, dp(200)))
        setContentView(root)
        refreshTitle()
    }

    private fun highlight(e: Editable) {
        e.getSpans(0, e.length, ForegroundColorSpan::class.java).forEach { e.removeSpan(it) }
        for ((re, color) in rules) re.findAll(e).forEach {
            e.setSpan(ForegroundColorSpan(color), it.range.first, it.range.last + 1, Editable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun refreshTitle() { title.text = "📄 " + (current ?: "sem título") }

    private fun call(path: String) {
        if (busy) return
        busy = true; out.text = "⏳ Compilando…"
        val req = JSONObject().put("channel", "stable").put("mode", "debug").put("edition", "2021")
            .put("crateType", "bin").put("tests", false).put("backtrace", false).put("code", editor.text.toString())
        thread {
            val msg = try {
                val r = post(path, req)
                if (path == "format" && r.optBoolean("success")) {
                    val f = r.getString("code"); runOnUiThread { editor.setText(f) }; "✓ Formatado"
                } else (r.optString("stdout") + r.optString("stderr")).ifBlank { "✓ OK" }
            } catch (e: Exception) { "Erro de rede: ${e.message}" }
            runOnUiThread { out.text = msg; busy = false }
        }
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val c = URL("https://play.rust-lang.org/$path").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val s = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        return JSONObject(s)
    }

    private fun newFile() { current = null; editor.setText(template); refreshTitle() }

    private fun openFile() {
        val names = filesDir.listFiles { f -> f.extension == "rs" }?.map { it.name }?.sorted() ?: emptyList()
        if (names.isEmpty()) { toast("Nenhum arquivo salvo"); return }
        AlertDialog.Builder(this).setTitle("Abrir").setItems(names.toTypedArray()) { _, i ->
            current = names[i]; editor.setText(File(filesDir, names[i]).readText()); refreshTitle()
        }.show()
    }

    private fun save() {
        current?.let { File(filesDir, it).writeText(editor.text.toString()); toast("Salvo"); return }
        val input = EditText(this).apply { hint = "nome (ex: main)" }
        AlertDialog.Builder(this).setTitle("Salvar como").setView(input).setPositiveButton("Salvar") { _, _ ->
            val n = input.text.toString().trim().removeSuffix(".rs").ifBlank { "main" } + ".rs"
            current = n; File(filesDir, n).writeText(editor.text.toString()); refreshTitle(); toast("Salvo")
        }.show()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
