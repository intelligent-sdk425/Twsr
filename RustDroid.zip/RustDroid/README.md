# RustDroid
Editor Rust para Android (destaque de sintaxe, abrir/salvar, Rodar, Clippy, Formatar).
Compila no servidor do Rust Playground (precisa de internet). Sem cargo/crates externos.

## Gerar o APK
1. Crie um repositório no GitHub e envie esta pasta (inclusive .github).
2. Aba Actions > Build APK > aguarde ~3 min.
3. Baixe o artefato RustDroid-apk (app-debug.apk, já assinado) e instale no celular.

Local: `gradle assembleDebug` com Android SDK + JDK 17.
